package com.cg.linked.step;
import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.linkedin.pojo.LinkedForm.LinkedPojo;
import com.cg.linkedin.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LinkedStep {

	private WebDriver driver;
	private LinkedPojo pojo;
	DriverUtil util = new DriverUtil();
	
	@Before
	public void Initialization() {
		driver = util.driverUtil("chrome");
		
		
		pojo = new LinkedPojo();
		PageFactory.initElements(driver, pojo);
	}
	
	@After
	public void tearDown() {
		util.close();
	}
		
	
	
	@Test
	public void test() throws Throwable {
		i_have_open_the_browser();
		i_open_login_website();
		login_button_should_exists();
		Thread.sleep(3000);

	}
	@Given("^I have open the browser$")
	public void i_have_open_the_browser() throws Throwable {
	   driver.get("https://www.linkedin.com/");
	}

	@When("^I open login website$")
	public void i_open_login_website() throws Throwable {
	  pojo.setFname("sravya");
	  pojo.setLname("Manda");
	  pojo.seteMail("jyothisravya1997@gmail.com");
	  pojo.setPwd("srav@123");
	  
	}

	@Then("^Login button should exists$")
	public void login_button_should_exists() throws Throwable {
	   pojo.join();
	}


}
