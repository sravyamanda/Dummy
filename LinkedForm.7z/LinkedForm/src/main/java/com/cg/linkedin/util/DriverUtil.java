package com.cg.linkedin.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverUtil {
	WebDriver driver;

	public WebDriver driverUtil(String name) {

		if ("chrome".equals(name)) {
			System.setProperty("webdriver.chrome.driver", "Drivers//chromedriver.exe");
			driver = new ChromeDriver();
			return driver;
		}

		else if ("firefox".equals(name)) {
			System.setProperty("webdriver.firefox.driver", "Drivers//firefoxdriver.exe");
			driver = new FirefoxDriver();
			return driver;
		} else {
			System.setProperty("webdriver.internetexplorer.driver", "Drivers//internetexplorerdriver.exe");
			driver = new InternetExplorerDriver();
			return driver;
		}
	} 
	
	public void close() {
		driver.quit();

	}
}
