package com.cg.linkedin.pojo.LinkedForm;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LinkedPojo {

	@FindBy(how=How.ID,using="reg-firstname")
	private WebElement fname;
	
	@FindBy(how=How.ID,using="reg-lastname")
	private WebElement lname;
	
	@FindBy(how=How.ID,using="reg-email")
	private WebElement eMail;
	
	@FindBy(how=How.ID,using="reg-password")
	private WebElement pwd;
	
	@FindBy(how=How.ID,using="registration-submit")
	private WebElement sub;

	public String getFname() {
		return fname.getAttribute("value");
	}
	public void setFname(String fname) {
		this.fname.sendKeys(fname);;
	}
	public String getLname() {
		return lname.getAttribute("value");
	}
	public void setLname(String lname) {
		this.lname.sendKeys(lname);;
	}
	public String geteMail() {
		return eMail.getAttribute("value");
	}
	public void seteMail(String eMail) {
		this.eMail.sendKeys(eMail);;
	}
	public String getPwd() {
		return pwd.getAttribute("value");
	}
	public void setPwd(String pwd) {
		this.pwd.sendKeys(pwd);;
	}
	public void join() {
		sub.click();
	}
	
}
