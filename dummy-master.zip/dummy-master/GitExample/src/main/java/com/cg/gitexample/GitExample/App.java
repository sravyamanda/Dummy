package com.cg.gitexample.GitExample;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Saikrishna Muthyala" );
    }
}
