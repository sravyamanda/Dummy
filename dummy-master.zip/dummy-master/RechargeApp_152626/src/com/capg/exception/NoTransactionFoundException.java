package com.capg.exception;

public class NoTransactionFoundException extends Exception {
	/**
	 * 
	 */
private static final long serialVersionUID=1L;
}
