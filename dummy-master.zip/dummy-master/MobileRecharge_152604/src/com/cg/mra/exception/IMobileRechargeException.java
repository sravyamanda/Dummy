package com.cg.mra.exception;

public interface IMobileRechargeException {
	String MESSAGE1 = "Given Account Id Does Not Exists";
	String MESSAGE2 = "Cannot Recharge Account as Given Mobile No Does Not Exists";
	String MESSAGE3 = "ENTER CORRECT AMOUNT TO PROCESS";
}
