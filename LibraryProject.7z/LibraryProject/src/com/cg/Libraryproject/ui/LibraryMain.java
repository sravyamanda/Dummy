package com.cg.Libraryproject.ui;

import java.util.Scanner;

import com.cg.Libraryproject.dto.MemberDto;
import com.cg.Libraryproject.exception.LibraryException;
import com.cg.Libraryproject.service.ILibraryService;
import com.cg.Libraryproject.service.LibraryServiceImpl;

public class LibraryMain {

	public static void main(String[] args) throws LibraryException {
		// TODO Auto-generated method stub
Scanner scr = new Scanner(System.in);

ILibraryService service=new LibraryServiceImpl();
System.out.println("1.view member details");
System.out.println("2.pay amount");
System.out.println("3.exit");

int choice=0;

do {
	System.out.println("Enter the choice");
	choice = scr.nextInt();
	
	switch (choice) {
	case 1:
		System.out.println("Enter Id");
		String mId=scr.next();
		MemberDto dto=service.viewdetails(mId);
		
		if(dto!=null) {
			System.out.println(dto.getmId());
			System.out.println(dto.getmName());
			System.out.println(dto.getMamount());
			if(dto.getMamount()<0) {
				System.out.println("Fine to be paid");
			}else {
				System.out.println("eligibile for issuing book");
			}
		}else
		{
			System.out.println("not found");
		}
		
	
		break;
	
	case 2:
		String id=scr.next();
	
		service.payAmount(id);
	break;
}
	

}while(choice<3);
	}

}
