package com.cg.Libraryproject.dao;

import com.cg.Libraryproject.dto.MemberDto;

public interface ILibraryDao {

	
	MemberDto viewdetails(String mId);

	void payAmount(String id);

}
