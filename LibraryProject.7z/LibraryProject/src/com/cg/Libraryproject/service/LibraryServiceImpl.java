package com.cg.Libraryproject.service;

import java.util.regex.Pattern;

import com.cg.Libraryproject.dao.ILibraryDao;
import com.cg.Libraryproject.dao.LibraryDaoImpl;
import com.cg.Libraryproject.dto.MemberDto;
import com.cg.Libraryproject.exception.ILibraryException;
import com.cg.Libraryproject.exception.LibraryException;

public class LibraryServiceImpl implements ILibraryService{
	ILibraryDao dao=null;
	public LibraryServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new LibraryDaoImpl();
	}
	@Override
	public MemberDto viewdetails(String mId) {
		if(!Pattern.matches("^[0-9a-zA-Z]+", mId))
			try {
				throw new LibraryException(ILibraryException.ERROR1);
			} catch (LibraryException e) {
				System.out.println(e.getMessage());
			}
		return dao.viewdetails(mId);
	}
	@Override
	public void payAmount(String id) {
		if(!Pattern.matches("^[0-9a-zA-Z]+", id))
			try {
				throw new LibraryException(ILibraryException.ERROR1);
			} catch (LibraryException e) {
				System.out.println(e.getMessage());
			}
		dao.payAmount(id);
	}
	
	
	
	
}
