package com.cg.Libraryproject.service;

import com.cg.Libraryproject.dto.MemberDto;

public interface ILibraryService {

	MemberDto viewdetails(String mId);


	void payAmount(String id);


}
