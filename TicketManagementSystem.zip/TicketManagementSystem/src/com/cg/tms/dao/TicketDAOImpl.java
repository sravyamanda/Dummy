package com.cg.tms.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.util.Util;

public class TicketDAOImpl implements TicketDAO{
	private static Map<String,TicketBean> ticketLog=new HashMap<String, TicketBean>();
	Util u=new Util();
	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		// TODO Auto-generated method stub
		ticketLog.put(ticketBean.getTicketNo(),ticketBean);
		return true;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		Map<String, String> ticketCategory=new HashMap<String,String>();
		ticketCategory=Util.getTicketCategoryEntries();
		List<TicketCategory> ticketcategorylist=new ArrayList<>();
		Set<String> keys = ticketCategory.keySet();
		 for(String key: keys){
	            TicketCategory ticket=new TicketCategory();
	            ticket.setTicketCategoryId(key);
	            ticket.setCategoryName(ticketCategory.get(key));
	            ticketcategorylist.add(ticket);
	        }
		
		
		
		
		return ticketcategorylist;
	}

}
