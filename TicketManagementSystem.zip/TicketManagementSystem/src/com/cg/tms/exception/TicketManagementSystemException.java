package com.cg.tms.exception;

public class TicketManagementSystemException extends Exception{

	public TicketManagementSystemException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TicketManagementSystemException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
