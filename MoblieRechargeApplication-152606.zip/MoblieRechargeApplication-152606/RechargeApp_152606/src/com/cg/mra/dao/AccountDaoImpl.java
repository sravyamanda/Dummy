package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Scanner;


import com.cg.mra.beans.Account;

public class AccountDaoImpl implements AccountDao {

	private static HashMap<String, Account> AccountEntry = null;
	static {
		AccountEntry = new HashMap<>();
		Account acc = new Account();
		acc.setMobileNo("9848935458");
		acc.setAccountType("idea");
		acc.setCustomerName("Priya");
		acc.setAccountBalance(100);
		Account acc1 = new Account();
		acc1.setMobileNo("7661891138");
		acc1.setAccountType("Airtel");
		acc1.setCustomerName("Ravi");
		acc1.setAccountBalance(200);
		Account acc2 = new Account();
		acc2.setMobileNo("9603116338");
		acc2.setAccountType("Uninor");
		acc2.setCustomerName("Kavitha");
		acc2.setAccountBalance(300);

		AccountEntry.put(acc.getMobileNo(), acc);
		AccountEntry.put(acc1.getMobileNo(), acc1);
		AccountEntry.put(acc2.getMobileNo(), acc2);
	}
	//------------------------    <Recharge> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	:	<getAccountDetails>
	 - Input Parameters	:	<mobileNo> <String>
	 - Return Type		:	<Account> <Account>
	 - Author			:	<Vemsani Priya Chowdary>
	 - Creation Date	:	11/07/2018
	 ********************************************************************************************************/


	@Override
	public Account getAccountDetails(String mobileNo) {
		Account dto = AccountEntry.get(mobileNo);
		if (dto != null) {
			return dto;
		}

		return null;
	}
	//------------------------    <Recharge> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	:	<rechargeAccount>
		 - Input Parameters	:	<mobileNo,rechargeAmount> <String,double>
		 - Return Type		:	<double> <double>
		 - Author			:	<Vemsani Priya Chowdary>
		 - Creation Date	:	11/07/2018
		 ********************************************************************************************************/



	@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		Account dto=AccountEntry.get(mobileNo);
		Scanner sc = new Scanner(System.in);
		if(dto!=null)
		{
			
			double updateBal=dto.getAccountBalance()+rechargeAmount;
			System.out.println("hello"+" "+dto.getCustomerName());
			
			dto.setAccountBalance(updateBal);
			return updateBal;
			
		}
		return 0;
	}

}
