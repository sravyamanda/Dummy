package com.cg.mra.exception;

public class AccountServiceExceptionImpl extends Exception{
	
	public AccountServiceExceptionImpl() {
		super();
	}
    public AccountServiceExceptionImpl(String arg0) {
		super(arg0);
	}
	

}
