package com.cg.mra.exception;

public interface AccountServiceException {
	String ERROR1 = "Please enter correct mobile number";
	String ERROR2 = "please enter correct amount";

}
