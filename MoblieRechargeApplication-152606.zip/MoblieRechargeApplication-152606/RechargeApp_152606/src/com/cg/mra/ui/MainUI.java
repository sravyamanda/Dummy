package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.exception.AccountServiceExceptionImpl;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
		AccountService service = new AccountServiceImpl();
		boolean error = false;
		boolean error1 = false;
		int choice = 0;
		do {
			System.out.println("1.Account Balance Summary");
			System.out.println("2. Recharge Account");
			System.out.println("3.Exit");

			System.out.println("enter your choice");
			choice = scanner.nextInt();

			switch (choice) {
			case 1: {
				System.out.println("Please enter your mobile number");
				String mobileNo = scanner.next();
				try {
					error = service.validateMobileNo(mobileNo);
				} catch (AccountServiceExceptionImpl e) {
					System.out.println(e.getMessage());
					// e.printStackTrace();
				}
				if (error) {
					Account details = service.getAccountDetails(mobileNo);
					if (details != null) {

						System.out.println("Your Current Balance is Rs." + "" + details.getAccountBalance());
					} else {
						System.out.println("ERROR: Given Account id Does Not Exists");
					}
				}
				break;

			}
			case 2: {
				System.out.println("Enter Mobile Number");
				String mobileNo = scanner.next();
				System.out.println("enter recharge Amount");

				Double rechargeAmount = scanner.nextDouble();

				double details1 = service.rechargeAccount(mobileNo, rechargeAmount);
				try {
					error = service.validateMobileNo(mobileNo);

				} catch (AccountServiceExceptionImpl e) {
					System.out.println(e.getMessage());

				}
				try {
					error1 = service.validateAmount(rechargeAmount);
				} catch (AccountServiceExceptionImpl e) {
					System.out.println(e.getMessage());
				}

				if (error && error1) {
					if (details1 != 0) {
						Account det = new Account();
						System.out.println("yout Account recharged Successfully");
						System.out.println("Available Balance is" + details1);
					} else {
						System.out.println("ERROR: Cannot Recharge Account as Given mobile No Does Noe Exists");

					}
				}
				break;

			}
			case 3:
				System.out.println("thankyou for using");
				System.exit(0);
				break;
			default:
				System.out.println("enter correct value");

			}

		} while (choice <= 3);

	}

}
