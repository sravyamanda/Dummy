package com.capg.step;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.capg.pojo.LoginPojo;
import com.capg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinitionFile {
	
	private WebDriver driver;
	private LoginPojo pojo;
	DriverUtil util = new DriverUtil();
	
	@Before
	public void Initialization() {
		driver = util.driverUtil("chrome");
		
		
		pojo = new LoginPojo();
		PageFactory.initElements(driver, pojo);
	}
	
@After
public void tearDown() {
	util.close();
}
	
	
	
	@Test
	public void test() throws Throwable {
		i_have_open_the_browser();
		i_open_login_website();
		login_button_should_exists();
		Thread.sleep(5000);
	}
	
	
	@Given("^I have open the browser$")
	public void i_have_open_the_browser() throws Throwable {
		
	 driver.get("D:\\Module 3\\sravya\\bdd\\LoginForm\\WebContent\\Form.html");
	}

	@When("^I open login website$")
	public void i_open_login_website() throws Throwable {
	    pojo.setUsername("sravya");
	    pojo.setPassword("honey");
	}

	@Then("^Login button should exists$")
	public void login_button_should_exists() throws Throwable {
		
	  pojo.clicksubmit();
	}

}
