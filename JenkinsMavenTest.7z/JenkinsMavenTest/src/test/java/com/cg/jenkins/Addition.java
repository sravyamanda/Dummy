package com.cg.jenkins;

import static org.junit.Assert.*;

import org.junit.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Addition {

	@Test
	public void callme() {
		the_two_numbers_are_and();
		the_number_are_added();
		the_result_is() ;
	}
	
	@Given("^The two numbers are (\\d+) and (\\d+)$")
	public void the_two_numbers_are_and()  {
		System.out.println("I am in given");
	}

	@When("^The number are added$")
	public void the_number_are_added()  {
		System.out.println("I am in when");
	
	}

	@Then("^The result is (\\d+)$")
	public void the_result_is()  {
		System.out.println("I am in then");
	  
	}
}
