package com.cg.jenkins;

import static org.junit.Assert.*;

import org.junit.Test;

public class frytyftytyftyftyftyyyftyfy {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
